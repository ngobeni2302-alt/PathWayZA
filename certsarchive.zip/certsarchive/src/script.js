// Highlight a certificate when clicked
const certificates = document.querySelectorAll(".certificate");

certificates.forEach(certificate => {
    certificate.addEventListener("click", function () {
        this.style.backgroundColor = "#e8f5e9";
    });
});